extends Node

var music_player: AudioStreamPlayer
var music_enabled: bool = true

func _ready() -> void:
	music_player = AudioStreamPlayer.new()
	add_child(music_player)

	music_player.volume_db = -12.0

	var music = load("res://Meadow Thoughts.ogg")

	if music == null:
		push_error("Music file not found!")
		return

	music.loop = true
	music_player.stream = music
	music_player.play()

func toggle_music() -> void:
	music_enabled = not music_enabled

	if music_player != null:
		music_player.stream_paused = not music_enabled
