shader_type canvas_item;

uniform vec4 glow_color : source_color = vec4(0.25, 0.75, 1.0, 1.0);
uniform float glow_strength : hint_range(0.0, 3.0) = 0.7;
uniform float glow_radius : hint_range(0.0, 12.0) = 4.0;

void fragment() {
    vec4 tex = texture(TEXTURE, UV);
    vec2 pixel_size = TEXTURE_PIXEL_SIZE;

    float glow = 0.0;

    for (int x = -4; x <= 4; x++) {
        for (int y = -4; y <= 4; y++) {
            vec2 offset = vec2(float(x), float(y)) * pixel_size * glow_radius;
            vec4 sample_color = texture(TEXTURE, UV + offset);
            glow = max(glow, sample_color.a);
        }
    }

    float outer_glow = max(glow - tex.a, 0.0);

    vec3 final_color = tex.rgb + glow_color.rgb * glow_strength * tex.a;

    COLOR = vec4(
        mix(final_color, glow_color.rgb, outer_glow * 0.7),
        max(tex.a, outer_glow * 0.6)
    );
}
