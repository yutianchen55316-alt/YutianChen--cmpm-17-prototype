extends Area2D

var changing_level := false

func _ready() -> void:
	monitoring = true
	print("LEVEL 2 EXIT READY")

func _on_body_entered(body: Node2D) -> void:
	if changing_level or body.name != "player":
		return

	changing_level = true
	print("ENTERING LEVEL 3")
	get_tree().call_deferred("change_scene_to_file", "res://level_3.tscn")
