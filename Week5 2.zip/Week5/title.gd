
extends TextureRect

# Floating animation settings
@export var float_distance: float = 6.0
@export var float_duration: float = 1.8

# Breathing animation settings
@export var glow_duration: float = 1.8
@export var normal_color: Color = Color(1.0, 1.0, 1.0, 1.0)
@export var glow_color: Color = Color(0.78, 0.72, 1.0, 1.0)

# Scale animation settings
@export var scale_amount: float = 1.03

var original_position: Vector2
var original_scale: Vector2


func _ready() -> void:
	original_position = position
	original_scale = scale

	# Make scaling happen from the center
	pivot_offset = size / 2.0

	start_floating()
	start_glowing()
	start_scaling()


# 1. Floating animation
func start_floating() -> void:
	var tween = create_tween()
	tween.set_loops()
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)

	tween.tween_property(
		self,
		"position:y",
		original_position.y - float_distance,
		float_duration
	)

	tween.tween_property(
		self,
		"position:y",
		original_position.y,
		float_duration
	)


# 2. Breathing color animation
func start_glowing() -> void:
	var tween = create_tween()
	tween.set_loops()
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)

	tween.tween_property(
		self,
		"modulate",
		glow_color,
		glow_duration
	)

	tween.tween_property(
		self,
		"modulate",
		normal_color,
		glow_duration
	)


# 3. Gentle scaling animation
func start_scaling() -> void:
	var tween = create_tween()
	tween.set_loops()
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)

	tween.tween_property(
		self,
		"scale",
		original_scale * scale_amount,
		float_duration
	)

	tween.tween_property(
		self,
		"scale",
		original_scale,
		float_duration
	)
