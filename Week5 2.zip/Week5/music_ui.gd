extends CanvasLayer

@onready var music_button: Button = $MusicButton

func _ready() -> void:
	update_button()

func _on_music_button_pressed() -> void:
	MusicManager.toggle_music()
	update_button()

func update_button() -> void:
	if MusicManager.music_enabled:
		music_button.text = "Music ON"
	else:
		music_button.text = "Music OFF"
