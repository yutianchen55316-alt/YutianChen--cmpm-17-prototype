
extends Area2D

var changing_level = false

func _ready() -> void:
	monitoring = true
	print("Level 1 exit is ready!")

func _on_body_entered(body: Node2D) -> void:
	print("Something entered: ", body.name)

	if changing_level:
		return

	if body is CharacterBody2D:
		changing_level = true
		print("Changing to Level 2!")

		get_tree().call_deferred(
			"change_scene_to_file",
            "res://level_2.tscn"
		)
